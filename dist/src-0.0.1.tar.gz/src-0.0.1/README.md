conda create -n my python=3.9.11\n

conda activate my

touch requirements.txt

pip install -r requirements.txt

create template.py to create files and folder 

git init 
dvc init 
dvc add dataset 
git add 
git commit 
create repo 
git remote add origin 
git branch -m main 
git push origin 